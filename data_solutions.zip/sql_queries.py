import pandas as pd
import sqlite3

def main():
    con = sqlite3.connect('exercise_database.db')
    df1 = pd.read_sql_query('SELECT iso,AVG(score) FROM reviews GROUP BY iso',con)
    df2 = pd.read_sql_query('SELECT apps_bought_bucket,MAX(score) FROM reviews GROUP BY apps_bought_bucket',con)
    df3 = pd.read_sql_query('SELECT date,AVG(score) FROM reviews GROUP BY date',con)
    df4 = pd.concat([df1,df2,df3],axis=1)
    df4.to_csv('sql_query_results.csv',index=False)
    con.close()

if __name__ == '__main__':
    main()
