import pandas as pd
import re

def clean_file(df):
    df = df.drop(['product_name'],axis=1)
    df = df.rename(columns={'app_bought':'apps_bought'})
    df['date'] = df['date'].str.replace('6/9/17','17/6/9')
    df['date'] = pd.to_datetime(df.date,yearfirst=True)
    #removing most emojis
    df['title'] = df['title'].str.replace('[\U00010000-\U0010ffff]','', flags=re.UNICODE)
    df['review'] = df['review'].str.replace('[\U00010000-\U0010ffff]','', flags=re.UNICODE)
    return df

def create_buckets(df):
    df['apps_bought_bucket'] = pd.cut(df['apps_bought'],bins=[0,20,40,60,80,100],labels=['0-20','21-40','41-60','61-80','81-100'],include_lowest=True)
    df['money_spent_bucket'] = pd.cut(df['money_spent'],bins=[0,100,200,300,400,500],labels=['0-100','101-200','201-300','301-400','401-500'],include_lowest=True)
    return df

def main():
    df = pd.read_csv('reddit_exercise_data.csv',encoding='utf-8')
    df = clean_file(df)
    df = create_buckets(df)
    df.to_csv('reddit_exercise_data_cleaned.csv',encoding='utf-8',index=False)

if __name__ == '__main__':
    main()
