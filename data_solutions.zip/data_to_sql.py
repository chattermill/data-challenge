import sqlite3
import pandas as pd

def main():
    con = sqlite3.connect('exercise_database.db')
    df = pd.read_csv('reddit_exercise_data_cleaned.csv',index_col = 0)
    df.to_sql("reviews",con,if_exists = 'append')
    con.close()

if __name__ == '__main__':
    main()
