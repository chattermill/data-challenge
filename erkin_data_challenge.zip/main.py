import pandas as pd
import sqlite3
from dateutil import parser

QUERIES = {
    'iso_average': 'SELECT iso, AVG(score) average_score FROM reviews GROUP BY iso',
    'quartile_max': 'SELECT apps_bought_bucket, max(score) max_score FROM reviews GROUP BY apps_bought_bucket',
    'date_average': 'SELECT date, ROUND(AVG(score), 2) average_score FROM reviews GROUP BY date'
}

def transform_df(dataframe):
    result = dataframe.copy()
    for index, row in dataframe.iterrows():
        result.loc[index, 'date'] = parser.parse(row['date']).strftime('%Y-%m-%d')
    result['apps_bought_bucket'] = pd.qcut(dataframe['app_bought'], 4, labels=False)
    result['money_spent_bucket'] = pd.qcut(dataframe['money_spent'], 4, labels=False)

    result['review'] = dataframe['review'].astype(str)
    result['title'] = result['title'].astype(str)
    result['iso'] = result['iso'].astype(str)
    result['score'] = result['score'].astype(int)
    result['date'] = result['date'].astype(str)
    result['app_bought'] = result['app_bought'].astype(int)
    result['money_spent'] = result['money_spent'].astype(float)
    result['apps_bought_bucket'] = result['apps_bought_bucket'].astype(str)
    result['money_spent_bucket'] = result['money_spent_bucket'].astype(str)
    return result


def parse_raw_file(infile, outfile):
    conn = sqlite3.connect('exercise_database.db')

    df = pd.read_csv(infile)
    df = transform_df(df)
    df.to_csv(outfile, index=False, encoding='utf-8')
    df.to_sql('reviews', conn, if_exists='replace', index=False)


def query_sql(query_name):
    conn = sqlite3.connect('exercise_database.db')

    return pd.read_sql_query(QUERIES[query_name], conn)


if __name__ == '__main__':
    parse_raw_file('reddit_exercise_data.csv', 'clean.csv')

    for query in QUERIES:
        print(query_sql(query))